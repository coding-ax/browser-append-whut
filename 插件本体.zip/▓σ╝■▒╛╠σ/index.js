document.querySelector(".black_overlay").remove();
document.querySelector(".white_content").remove();